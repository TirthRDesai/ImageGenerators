from fastapi import APIRouter
from pydantic import BaseModel
from helpers.login import login_user
from helpers.signup import signup_user

router = APIRouter(
    prefix="/auth",
    tags=["Authentication"],
)


class LoginRequest(BaseModel):
    username: str
    password: str
    is_encrypted: bool


@router.post("/login")
def login(request: LoginRequest):
    login_request_data = request.model_dump()
    # Implement login logic here
    username = login_request_data["username"]
    password = login_request_data["password"]
    is_encrypted = login_request_data["is_encrypted"]
    login_result = login_user(username, password, is_encrypted)
    if not login_result["status"]:
        return {"message": login_result["message"], "status": False}

    return {"message": "User logged in", "status": True, "user": login_result["user"]}


class SignupRequest(BaseModel):
    username: str
    password: str
    name: str
    email: str


@router.post("/signup")
def signup(request: SignupRequest):
    signup_request_data = request.model_dump()
    # Implement signup logic here
    username = signup_request_data["username"]
    password = signup_request_data["password"]
    name = signup_request_data["name"]
    email = signup_request_data["email"]
    signup_result = signup_user(username, password, name, email)
    if not signup_result["status"]:
        return {"message": signup_result["message"], "status": False}

    return {"message": "User signed up successfully", "status": True, "user": signup_result["user"]}
