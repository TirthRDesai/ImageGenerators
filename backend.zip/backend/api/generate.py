import os
from typing import Literal
from sqlalchemy.orm import Session
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from database.db import get_db
from crud.generated_images import create_generated_image_record, get_generated_images
from services.generate_service import (
    build_public_url,
    fetch_status,
    start_generation,
)

router = APIRouter(
    prefix="/generate",
    tags=["Image Generation"],
)


class GenerateRequest(BaseModel):
    prompt: str
    model_id: str
    user_token: str
    username: str


@router.post("/image")
async def generate_image(request: GenerateRequest):
    response = start_generation(request)
    return {
        "message": "Image generation started",
        "status": True,
        "token": response["token"],
    }


@router.get("/get_status/{token}")
def get_generation_status(token: str, db: Session = Depends(get_db)):
    response = fetch_status(token)
    if response.get("status") == "failed":
        record = create_generated_image_record(
            db=db,
            generated_by=response.get("username"),
            model_used=response.get("model_id"),
            prompt=response.get("prompt"),
            image_name=None,
            status="Failed",
            error=response.get("error"),
        )
    if response.get("status") == "completed":
        output_file = response.get("result", {}).get("output_file")
        image_name = os.path.basename(output_file) if output_file else None
        record = create_generated_image_record(
            db=db,
            generated_by=response.get("username"),
            model_used=response.get("model_id"),
            prompt=response.get("prompt"),
            image_name=image_name,
            status="Success",
            error=None,
        )
    return {"message": "Status retrieved", "status": True, "data": response}


@router.post("/fetch_generated_images/")
def fetch_generated_images(db: Session = Depends(get_db), ffrom: int = 0, to: int = 10):
    images = get_generated_images(db, ffrom, to)
    return {"message": "Generated images fetched", "status": True, "data": images}
