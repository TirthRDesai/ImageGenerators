
import os
import base64
from cryptography.exceptions import InvalidKey
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


def hash_password(password: str) -> str:
    salt = os.urandom(16)

    kdf = Scrypt(
        salt=salt,
        length=32,
        n=2**14,
        r=8,
        p=1,
        backend=default_backend()
    )

    key = kdf.derive(password.encode())

    # store salt + hash together
    return base64.b64encode(salt + key).decode()


def verify_password(password: str, actual_password: str) -> bool:
    data = base64.b64decode(actual_password.encode())
    salt = data[:16]
    key = data[16:]

    kdf = Scrypt(
        salt=salt,
        length=32,
        n=2**14,
        r=8,
        p=1,
        backend=default_backend()
    )

    try:
        kdf.verify(password.encode(), key)
        return True
    except InvalidKey:
        return False
