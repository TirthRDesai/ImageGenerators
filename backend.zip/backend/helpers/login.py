
from dotenv import load_dotenv
import os
from helpers.password_hashing import verify_password
from crud.users import get_user_by_username
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))


def login_user(username: str, password: str, is_encrypted: bool):
    from database.db import get_db
    from sqlalchemy.orm import Session

    db: Session = next(get_db())

    user = get_user_by_username(db, username)
    if not user:
        return {"message": "Invalid username or password", "status": False}
    print(f"User found: {user.username}")
    print(f"Password provided: {password}")
    print(f"Is encrypted: {is_encrypted}")
    print(f"Stored password: {user.password}")
    if is_encrypted:
        if password == user.password:
            return {"message": "User logged in", "status": True, "user": user}
        else:
            password_to_check = password
    else:
        password_to_check = password

    if verify_password(password_to_check, user.password):
        return {"message": "User logged in", "status": True, "user": user}
    else:
        return {"message": "Invalid username or password", "status": False}
