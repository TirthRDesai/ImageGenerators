from dotenv import load_dotenv
import os
from helpers.password_hashing import verify_password
from crud.users import get_user_by_email_or_username, get_user_by_username
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))


def signup_user(username: str, password: str, name: str, email: str):
    from database.db import get_db
    from database.models import User
    from sqlalchemy.orm import Session
    from helpers.password_hashing import hash_password

    db: Session = next(get_db())

    existing_user = get_user_by_email_or_username(db, email, username)
    if existing_user:
        return {"message": "Email or username already exists", "status": False}

    hashed_password = hash_password(password)
    new_user = User(username=username, password=hashed_password,
                    name=name, email=email)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    user = get_user_by_username(db, username)
    return {"message": "User signed up successfully", "status": True, "user": user}
