import argparse
import json
import os
import time
import uuid
from typing import Any, Dict, Optional, Tuple

import requests
from requests.adapters import HTTPAdapter


COMFY_SERVER = "http://192.168.1.215:8188"
COMFY_TIMEOUT_S = 300.0

COMFY_SESSION = requests.Session()
COMFY_SESSION.mount(
    "http://",
    HTTPAdapter(pool_connections=20, pool_maxsize=20, max_retries=1),
)


# -----------------------------
# Graph builders (Z-Turbo vs SDXL)
# -----------------------------

def build_z_turbo_graph(
    *,
    mode: str,  # "base", "pixel", or "anime"
    text: str,
    width: int = 1024,
    height: int = 1024,
    seed: int = 0,
    # common model bits (match your templates)
    unet_name: str = "z_image_turbo_bf16.safetensors",
    weight_dtype: str = "default",  # allowed on your install
    clip_name: str = "qwen_3_4b.safetensors",
    clip_type: str = "lumina2",     # required on your install
    clip_device: str = "default",
    vae_name: str = "ae.safetensors",
    shift: float = 3.0,
    # sampler defaults from your templates
    steps: int = 4,
    cfg: float = 1.0,
    sampler_name: str = "res_multistep",
    scheduler: str = "simple",
    denoise: float = 1.0,
    control_after_generate: str = "decrement",
    # pixel-only bits
    lora_name: str = "pixel_art_style_z_image_turbo.safetensors",
    lora_strength: float = 1.0,
    pixel_prefix: str = "Pixel art style, ",
    # anime-only bits
    anime_lora_name: str = "hina_zImageTurbo_anime_v2.52-dream.safetensors",
    anime_prefix: str = "anime style, illustrious style",
    # output
    filename_prefix: str = "z-image",
) -> Dict[str, Any]:
    """
    Returns a ComfyUI API 'prompt' graph (node_id -> {class_type, inputs}).

    mode="base"  uses the base template graph logic.
    mode="pixel" uses the LoRA template graph logic (adds LoraLoaderModelOnly).
    mode="anime" uses the anime LoRA template graph logic with anime trigger words.
    """
    mode = mode.lower().strip()
    if mode not in ("base", "pixel", "anime"):
        raise ValueError('mode must be "base", "pixel", or "anime"')

    # Match the template behavior: prefix + user prompt for pixel/anime modes
    if mode == "pixel":
        final_text = pixel_prefix + text
    elif mode == "anime":
        # Anime mode concatenates trigger words with user prompt (like the workflow)
        final_text = f"{anime_prefix}, {text}" if anime_prefix else text
    else:
        final_text = text

    # Anime mode uses 8 steps by default (from workflow JSON)
    if mode == "anime":
        steps = 8

    graph: Dict[str, Any] = {
        "28": {
            "class_type": "UNETLoader",
            "inputs": {
                "unet_name": unet_name,
                "weight_dtype": weight_dtype,
            },
        },
        "30": {
            "class_type": "CLIPLoader",
            "inputs": {
                "clip_name": clip_name,
                "type": clip_type,
                "device": clip_device,
            },
        },
        "29": {
            "class_type": "VAELoader",
            "inputs": {
                "vae_name": vae_name,
            },
        },
        "27": {
            "class_type": "CLIPTextEncode",
            "inputs": {
                "clip": ["30", 0],
                "text": final_text,
            },
        },
        "33": {
            "class_type": "ConditioningZeroOut",
            "inputs": {
                "conditioning": ["27", 0],
            },
        },
        "13": {
            "class_type": "EmptySD3LatentImage",
            "inputs": {
                "width": int(width),
                "height": int(height),
                "batch_size": 1,
            },
        },
        "3": {
            "class_type": "KSampler",
            "inputs": {
                "seed": int(seed),
                "control_after_generate": control_after_generate,
                "steps": int(steps),
                "cfg": float(cfg),
                "sampler_name": sampler_name,
                "scheduler": scheduler,
                "denoise": float(denoise),
                "positive": ["27", 0],
                "negative": ["33", 0],
                "latent_image": ["13", 0],
            },
        },
        "8": {
            "class_type": "VAEDecode",
            "inputs": {
                "samples": ["3", 0],
                "vae": ["29", 0],
            },
        },
        "60": {
            "class_type": "SaveImage",
            "inputs": {
                "images": ["8", 0],
                "filename_prefix": filename_prefix,
            },
        },
    }

    if mode == "pixel":
        graph["35"] = {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "model": ["28", 0],
                "lora_name": lora_name,
                "strength_model": float(lora_strength),
            },
        }
        graph["11"] = {
            "class_type": "ModelSamplingAuraFlow",
            "inputs": {
                "model": ["35", 0],
                "shift": float(shift),
            },
        }
        graph["3"]["inputs"]["model"] = ["11", 0]
    elif mode == "anime":
        graph["35"] = {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "model": ["28", 0],
                "lora_name": anime_lora_name,
                "strength_model": float(lora_strength),
            },
        }
        graph["11"] = {
            "class_type": "ModelSamplingAuraFlow",
            "inputs": {
                "model": ["35", 0],
                "shift": float(shift),
            },
        }
        graph["3"]["inputs"]["model"] = ["11", 0]
    else:
        graph["11"] = {
            "class_type": "ModelSamplingAuraFlow",
            "inputs": {
                "model": ["28", 0],
                "shift": float(shift),
            },
        }
        graph["3"]["inputs"]["model"] = ["11", 0]

    return graph


SDXL_DEFAULT_NEGATIVE_PROMPT = (
    "blurry, lowres, watermark, text, deformed, extra fingers, bad hands, oversaturated"
)


def build_sdxl_graph(
    *,
    text: str,
    width: int = 1024,
    height: int = 1024,
    seed: int = 0,
    ckpt_name: str = "sdXL_v10VAEFix.safetensors",
    negative_prompt: str = SDXL_DEFAULT_NEGATIVE_PROMPT,
    steps: int = 20,
    cfg: float = 5.0,
    sampler_name: str = "dpmpp_2m_sde",
    scheduler: str = "karras",
    denoise: float = 1.0,
    filename_prefix: str = "z-image",
) -> Dict[str, Any]:
    """
    Returns a ComfyUI API 'prompt' graph for SDXL.

    Built from workflows/SD-XL.json.
    """
    return {
        "44": {
            "class_type": "CheckpointLoaderSimple",
            "inputs": {
                "ckpt_name": ckpt_name,
            },
        },
        "27": {
            "class_type": "CLIPTextEncode",
            "inputs": {
                "clip": ["44", 1],
                "text": text,
            },
        },
        "43": {
            "class_type": "CLIPTextEncode",
            "inputs": {
                "clip": ["44", 1],
                "text": negative_prompt,
            },
        },
        "40": {
            "class_type": "EmptyLatentImage",
            "inputs": {
                "width": int(width),
                "height": int(height),
                "batch_size": 1,
            },
        },
        "3": {
            "class_type": "KSampler",
            "inputs": {
                "model": ["44", 0],
                "positive": ["27", 0],
                "negative": ["43", 0],
                "latent_image": ["40", 0],
                "seed": int(seed),
                "steps": int(steps),
                "cfg": float(cfg),
                "sampler_name": sampler_name,
                "scheduler": scheduler,
                "denoise": float(denoise),
            },
        },
        "8": {
            "class_type": "VAEDecode",
            "inputs": {
                "samples": ["3", 0],
                "vae": ["44", 2],
            },
        },
        "9": {
            "class_type": "SaveImage",
            "inputs": {
                "images": ["8", 0],
                "filename_prefix": filename_prefix,
            },
        },
    }


# -----------------------------
# ComfyUI HTTP client helpers
# -----------------------------

def _comfy_post_prompt(server: str, graph: Dict[str, Any], client_id: str, timeout_s: float = 60) -> str:
    with COMFY_SESSION.post(
        f"{server.rstrip('/')}/prompt",
        json={"prompt": graph, "client_id": client_id},
        timeout=timeout_s,
    ) as r:
        if not r.ok:
            raise RuntimeError(
                f"ComfyUI /prompt error {r.status_code}: {r.text}"
            )
        data = r.json()
        return data["prompt_id"]


def _comfy_wait_for_first_image(server: str, prompt_id: str, timeout_s: float = 180, poll_s: float = 0.5) -> Dict[str, Any]:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        with COMFY_SESSION.get(
            f"{server.rstrip('/')}/history/{prompt_id}", timeout=30
        ) as r:
            r.raise_for_status()
            hist = r.json()
        item = hist.get(prompt_id)
        if item and isinstance(item.get("outputs"), dict):
            for out in item["outputs"].values():
                if isinstance(out, dict) and out.get("images"):
                    return item
        time.sleep(poll_s)
    raise TimeoutError(
        f"Timed out waiting for image for prompt_id={prompt_id}")


def _comfy_download_first_image(server: str, history_item: Dict[str, Any], timeout_s: float = 60) -> Tuple[bytes, str]:
    for out in history_item.get("outputs", {}).values():
        if not isinstance(out, dict) or not out.get("images"):
            continue
        img = out["images"][0]
        params = {
            "filename": img["filename"],
            "subfolder": img.get("subfolder", ""),
            "type": img.get("type", "output"),
        }
        with COMFY_SESSION.get(
            f"{server.rstrip('/')}/view", params=params, timeout=timeout_s
        ) as r:
            r.raise_for_status()
            ext = os.path.splitext(img["filename"])[
                1].lstrip(".").lower() or "png"
            return r.content, ext
    raise RuntimeError("No images found in history outputs.")


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


WORKFLOW_FILES = {
    "z-turbo-base": os.path.join(BASE_DIR, "workflows", "z-turbo-base.json"),
    "z-turbo-pixel": os.path.join(BASE_DIR, "workflows", "z-turbo-pixel.json"),
    "z-turbo-anime": os.path.join(BASE_DIR, "workflows", "z-turbo-anime.json"),
    "sd-xl": os.path.join(BASE_DIR, "workflows", "SD-XL.json"),
    "sd-xl-anime": os.path.join(BASE_DIR, "workflows", "SD-XL-ANIME.json"),
    "sd-xl-anime-upscale": os.path.join(BASE_DIR, "workflows", "SD-XL-ANIME-UPSCALE.json"),
    "realvis-xl": os.path.join(BASE_DIR, "workflows", "RealVIS-XL.json"),
    "juggernaut-xl": os.path.join(BASE_DIR, "workflows", "Juggernaut-XL.json"),
    "dreamshaper-xl": os.path.join(BASE_DIR, "workflows", "DREAMSHAPER-XL.json"),
}

MODEL_TIMEOUTS = {
    "z-turbo": COMFY_TIMEOUT_S,
    "z-turbo-base": COMFY_TIMEOUT_S,
    "z-turbo-pixel": COMFY_TIMEOUT_S,
    "z-turbo-anime": COMFY_TIMEOUT_S,
    "sd-xl": COMFY_TIMEOUT_S,
    "sd-xl-anime": COMFY_TIMEOUT_S,
    "sd-xl-anime-upscale": 900.0,
    "realvis-xl": COMFY_TIMEOUT_S,
    "juggernaut-xl": COMFY_TIMEOUT_S,
    "dreamshaper-xl": COMFY_TIMEOUT_S,
}


SKIP_NODE_TYPES = {
    "MarkdownNote",
    "Note",
    "PrimitiveStringMultiline",
    "StringConcatenate",
}


def _load_workflow(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _build_link_map(links: Any) -> Dict[int, Tuple[int, int]]:
    link_map: Dict[int, Tuple[int, int]] = {}
    for link in links or []:
        if isinstance(link, dict):
            link_id = link.get("id")
            origin_id = link.get("origin_id")
            origin_slot = link.get("origin_slot")
        else:
            link_id = link[0] if len(link) > 0 else None
            origin_id = link[1] if len(link) > 1 else None
            origin_slot = link[2] if len(link) > 2 else None
        if link_id is not None and origin_id is not None and origin_slot is not None:
            link_map[int(link_id)] = (int(origin_id), int(origin_slot))
    return link_map


def _apply_widget_inputs(
    node_type: str,
    node_inputs: list,
    widget_values: list,
    inputs_out: Dict[str, Any],
) -> None:
    if node_type == "KSampler" and widget_values:
        if len(widget_values) >= 7:
            inputs_out["seed"] = widget_values[0]
            inputs_out["control_after_generate"] = widget_values[1]
            inputs_out["steps"] = widget_values[2]
            inputs_out["cfg"] = widget_values[3]
            inputs_out["sampler_name"] = widget_values[4]
            inputs_out["scheduler"] = widget_values[5]
            inputs_out["denoise"] = widget_values[6]
        elif len(widget_values) >= 6:
            inputs_out["seed"] = widget_values[0]
            inputs_out["steps"] = widget_values[1]
            inputs_out["cfg"] = widget_values[2]
            inputs_out["sampler_name"] = widget_values[3]
            inputs_out["scheduler"] = widget_values[4]
            inputs_out["denoise"] = widget_values[5]
        return

    widget_inputs = [
        item for item in (node_inputs or [])
        if item.get("widget") is not None
    ]
    for idx, item in enumerate(widget_inputs):
        if idx < len(widget_values):
            inputs_out[item["name"]] = widget_values[idx]


def _build_link_target_input_map(nodes: list) -> Dict[int, str]:
    link_to_target_input: Dict[int, str] = {}
    for node in nodes:
        for input_item in node.get("inputs") or []:
            link_id = input_item.get("link")
            if link_id is None:
                continue
            link_to_target_input[int(link_id)] = input_item.get("name")
    return link_to_target_input


def _find_text_node_targets(
    nodes: list,
    link_to_target_input: Dict[int, str],
) -> Tuple[set, set]:
    positive_nodes = set()
    negative_nodes = set()
    for node in nodes:
        if not any(inp.get("name") == "text" for inp in node.get("inputs") or []):
            continue
        for output in node.get("outputs") or []:
            for link_id in output.get("links") or []:
                input_name = link_to_target_input.get(int(link_id))
                if input_name == "positive":
                    positive_nodes.add(node.get("id"))
                elif input_name == "negative":
                    negative_nodes.add(node.get("id"))
    return positive_nodes, negative_nodes


def _graph_to_prompt(
    nodes: list,
    links: list,
    prompt: str,
    *,
    prompt_link_origin_ids: Optional[set] = None,
    subgraph_node_map: Optional[Dict[int, Dict[int, Tuple[int, int]]]] = None,
    allow_prompt_override: bool = True,
) -> Dict[str, Any]:
    link_map = _build_link_map(links)
    link_to_target_input = _build_link_target_input_map(nodes)
    positive_nodes, negative_nodes = _find_text_node_targets(
        nodes, link_to_target_input
    )
    has_positive_nodes = bool(positive_nodes)

    prompt_graph: Dict[str, Any] = {}
    prompt_applied = False

    for node in nodes:
        node_type = node.get("type")
        node_id = node.get("id")
        if (
            not node_type
            or node_type in SKIP_NODE_TYPES
            or (node.get("mode") == 4)
            or (subgraph_node_map and node_id in subgraph_node_map)
        ):
            continue

        inputs_out: Dict[str, Any] = {}
        _apply_widget_inputs(
            node_type,
            node.get("inputs") or [],
            node.get("widgets_values") or [],
            inputs_out,
        )

        for input_item in node.get("inputs") or []:
            link_id = input_item.get("link")
            if link_id is None:
                continue
            input_name = input_item.get("name")
            origin = link_map.get(int(link_id))
            if not origin:
                continue
            origin_id, origin_slot = origin

            if (
                prompt_link_origin_ids
                and origin_id in prompt_link_origin_ids
                and input_name == "text"
            ):
                inputs_out["text"] = prompt
                prompt_applied = True
                continue

            if subgraph_node_map and origin_id in subgraph_node_map:
                mapped = subgraph_node_map[origin_id].get(origin_slot)
                if not mapped:
                    continue
                origin_id, origin_slot = mapped

            if origin_id < 0:
                continue

            inputs_out[input_name] = [str(origin_id), origin_slot]

        if allow_prompt_override and not prompt_applied:
            has_text_input = any(
                inp.get("name") == "text" for inp in node.get("inputs") or []
            )
            if has_text_input:
                if node_id in positive_nodes:
                    inputs_out["text"] = prompt
                    prompt_applied = True
                elif not has_positive_nodes and node_id not in negative_nodes:
                    title = (node.get("title") or "").lower()
                    if "negative" not in title:
                        inputs_out["text"] = prompt
                        prompt_applied = True

        prompt_graph[str(node_id)] = {
            "class_type": node_type,
            "inputs": inputs_out,
        }

    return prompt_graph


def _subgraph_output_map(subgraph: Dict[str, Any]) -> Dict[int, Tuple[int, int]]:
    output_map: Dict[int, Tuple[int, int]] = {}
    link_map = _build_link_map(subgraph.get("links"))
    for idx, output in enumerate(subgraph.get("outputs") or []):
        link_ids = output.get("linkIds") or []
        if not link_ids:
            continue
        origin = link_map.get(int(link_ids[0]))
        if origin:
            output_map[idx] = origin
    return output_map


def _workflow_to_prompt(workflow: Dict[str, Any], prompt: str) -> Dict[str, Any]:
    definitions = workflow.get("definitions") or {}
    subgraphs = definitions.get("subgraphs") or []

    nodes = workflow.get("nodes") or []
    links = workflow.get("links") or []

    if not subgraphs:
        return _graph_to_prompt(nodes, links, prompt, allow_prompt_override=True)

    subgraph_by_id = {
        sg.get("id"): sg for sg in subgraphs if sg.get("id")
    }
    active_subgraph_ids = {
        node.get("type")
        for node in nodes
        if node.get("type") in subgraph_by_id and node.get("mode") != 4
    }
    if not active_subgraph_ids:
        return _graph_to_prompt(nodes, links, prompt, allow_prompt_override=True)

    subgraph_prompts: Dict[str, Dict[str, Any]] = {}
    subgraph_output_maps: Dict[str, Dict[int, Tuple[int, int]]] = {}
    for sg_id in active_subgraph_ids:
        subgraph = subgraph_by_id[sg_id]
        input_node_id = (subgraph.get("inputNode") or {}).get("id")
        prompt_ids = {input_node_id} if input_node_id is not None else None
        subgraph_prompts[sg_id] = _graph_to_prompt(
            subgraph.get("nodes") or [],
            subgraph.get("links") or [],
            prompt,
            prompt_link_origin_ids=prompt_ids,
            allow_prompt_override=False,
        )
        subgraph_output_maps[sg_id] = _subgraph_output_map(subgraph)

    subgraph_node_map: Dict[int, Dict[int, Tuple[int, int]]] = {}
    for node in nodes:
        node_type = node.get("type")
        if node_type in subgraph_output_maps and node.get("mode") != 4:
            subgraph_node_map[node.get("id")] = subgraph_output_maps[node_type]

    top_prompt = _graph_to_prompt(
        nodes,
        links,
        prompt,
        subgraph_node_map=subgraph_node_map,
        allow_prompt_override=False,
    )

    merged: Dict[str, Any] = {}
    for sg_id in active_subgraph_ids:
        merged.update(subgraph_prompts.get(sg_id, {}))
    merged.update(top_prompt)
    return merged


def _ensure_save_image_output(graph: Dict[str, Any]) -> Dict[str, Any]:
    if any(node.get("class_type") == "SaveImage" for node in graph.values()):
        return graph

    candidates = []
    for node_id, node in graph.items():
        if node.get("class_type") in ("ImageUpscaleWithModel", "VAEDecode"):
            try:
                numeric_id = int(node_id)
            except ValueError:
                numeric_id = -1
            candidates.append((numeric_id, node_id))

    if not candidates:
        raise RuntimeError("No IMAGE-producing node found to attach SaveImage")

    candidates.sort()
    target_node_id = candidates[-1][1]

    numeric_ids = [int(k) for k in graph.keys() if str(k).isdigit()]
    new_node_id = str((max(numeric_ids) if numeric_ids else 0) + 1)
    graph[new_node_id] = {
        "class_type": "SaveImage",
        "inputs": {
            "images": [target_node_id, 0],
            "filename_prefix": "z-image",
        },
    }
    return graph


def comfy_generate_image(
    *,
    model: str,
    prompt: str,
) -> Tuple[bytes, str, str]:
    """
    One call = one image.

    Returns (image_bytes, extension, prompt_id).
    """
    model_key = model.lower().strip()
    workflow_path = WORKFLOW_FILES.get(model_key)
    if not workflow_path:
        raise ValueError(f"Unknown model: {model}")

    timeout_s = MODEL_TIMEOUTS.get(model_key, COMFY_TIMEOUT_S)
    workflow = _load_workflow(workflow_path)
    graph = _workflow_to_prompt(workflow, prompt)
    graph = _ensure_save_image_output(graph)

    client_id = str(uuid.uuid4())
    prompt_id = _comfy_post_prompt(COMFY_SERVER, graph, client_id=client_id)
    history_item = _comfy_wait_for_first_image(
        COMFY_SERVER, prompt_id, timeout_s=timeout_s)
    img_bytes, ext = _comfy_download_first_image(COMFY_SERVER, history_item)
    return img_bytes, ext, prompt_id


def ensure_file_path(output_path: str) -> str:
    directory = os.path.dirname(output_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
    return output_path


def run(model: str, prompt: str, username: str) -> Tuple[bytes, str, str]:
    img_bytes, ext, pid = comfy_generate_image(
        model=model,
        prompt=prompt,
    )
    output_file = os.path.join(
        BASE_DIR, "storage", username, f"{pid}.{(ext or 'png').lower()}"
    )

    output_file = ensure_file_path(output_file)

    with open(output_file, "wb") as f:
        f.write(img_bytes)
        print(f"Saved output to {output_file}")
    return img_bytes, ext, pid, output_file

# def main() -> None:
#     ap = argparse.ArgumentParser()
#     ap.add_argument("--prompt", required=True, help="Text prompt")

#     ap.add_argument(
#         "--model",
#         choices=sorted(WORKFLOW_FILES.keys()),
#         default="z-turbo",
#         help="Workflow model to use",
#     )

#     args = ap.parse_args()

#     print(f"Using model: {args.model}")

#     img_bytes, ext, pid = comfy_generate_image(
#         model=args.model,
#         prompt=args.prompt,
#     )
#     output_path = os.path.join(BASE_DIR, "outputs", pid + "." + ext)
#     with open(output_path, "wb") as f:
#         f.write(img_bytes)
#     print(f"Saved to {output_path}")


# if __name__ == "__main__":
#     # Z-Turbo base
#     img_bytes, ext, pid = comfy_generate_image(
#         model="z-turbo-base",
#         prompt="a small robot in a forest",
#     )
#
#     # Z-Turbo pixel
#     img_bytes2, ext2, pid2 = comfy_generate_image(
#         model="z-turbo-pixel",
#         prompt="a small robot in a forest",
#     )
