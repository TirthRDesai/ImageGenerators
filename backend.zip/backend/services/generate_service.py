import uuid
from fastapi import HTTPException
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool
from services.model import run
import asyncio
import os

JOBS = {}
TOKEN_CACHE = {}


class GenerateRequest(BaseModel):
    model_id: str
    prompt: str
    user_token: str
    username: str


async def _run_job(job_id: str, model_id: str, prompt: str, username: str) -> None:
    JOBS[job_id]["status"] = "running"
    print(f"Starting job {job_id} with model {model_id}")
    try:
        _, ext, prompt_id, output_file = await run_in_threadpool(
            run, model_id, prompt, username
        )
        JOBS[job_id]["status"] = "completed"
        JOBS[job_id]["result"] = {
            "prompt_id": prompt_id,
            "ext": (ext or "png").lower(),
            "output_file": output_file,
        }
    except Exception as e:
        JOBS[job_id]["status"] = "failed"
        JOBS[job_id]["error"] = str(e)
        print(f"Job {job_id} failed with error: {e}")


def generate_job(request: GenerateRequest) -> dict:
    """Queue an image generation job and return a job id"""
    print(f"Received generate request: {request}")
    model_id = request.model_id.strip()
    if not model_id:
        raise HTTPException(status_code=400, detail="model_id is required")
    job_id = str(uuid.uuid4())
    JOBS[job_id] = {
        "status": "queued",
        "model_id": model_id,
        "prompt": request.prompt,
        "username": request.username,
        "result": None,
        "error": None,
    }

    TOKEN_CACHE[request.user_token] = job_id
    asyncio.create_task(
        _run_job(job_id, model_id, request.prompt, request.username))
    return {"token": request.user_token}


def start_generation(generate_request_data: GenerateRequest) -> dict:
    return generate_job(generate_request_data)


def fetch_status(token: str) -> dict:
    """Get the status of a job by token"""
    # types of status: queued, running, completed, failed
    job_id = TOKEN_CACHE.get(token)
    if not job_id or job_id not in JOBS:
        raise HTTPException(
            status_code=404, detail="Invalid token or job not found")

    job_info = JOBS[job_id]
    '''
        Output example:
        {
            "status": "completed",
            "model_id": "model_xyz",
            "prompt": "A beautiful sunset over the mountains",
            "username": "user123",
            "result": {
                "prompt_id": "abc123",
                "ext": "png",
                "output_file": "/path/to/generated/image.png"
            },
            "error": None
        }
    '''
    return job_info


def build_public_url(username: str, image_name: str) -> str:
    base_url = os.getenv("BACKEND_PUBLIC_URL", "").strip()
    if not base_url:
        server_host = os.getenv("SERVER_HOST", "127.0.0.1").strip()
        server_port = os.getenv("SERVER_PORT", "9001").strip()
        base_url = f"http://{server_host}:{server_port}"
    return f"{base_url.rstrip('/')}/storage/{username}/{image_name}"
