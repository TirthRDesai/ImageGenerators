from __future__ import annotations

from datetime import datetime
import enum

from sqlalchemy import BigInteger, DateTime, String, Text, func, text, Enum
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class ImageGenerationStatus(str, enum.Enum):
    Success = "Success"
    Failed = "Failed"


class User(Base):
    __tablename__ = "users"
    __table_args__ = {"schema": "public"}

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    username: Mapped[str] = mapped_column(
        String, nullable=False, unique=True, index=True)
    password: Mapped[str] = mapped_column(String, nullable=False)
    email: Mapped[str] = mapped_column(
        String, nullable=False, unique=True, index=True)

    name: Mapped[str] = mapped_column(
        Text,
        nullable=True,
        server_default=text("''::text"),
    )


class GeneratedImageRecord(Base):
    __tablename__ = "generated image records"  # table name has spaces
    __table_args__ = {"schema": "public"}

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    image_name: Mapped[str] = mapped_column(
        String,
        nullable=False,
        unique=True,
        server_default=text("(gen_random_uuid())::text || '.jpg'::text"),
    )

    generated_by: Mapped[str] = mapped_column(String, nullable=False)
    model_used: Mapped[str] = mapped_column(String, nullable=False)
    prompt: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[ImageGenerationStatus] = mapped_column(
        Enum(ImageGenerationStatus, name="image_generation_status"),
        nullable=False,
    )
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
