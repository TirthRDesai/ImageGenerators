from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from sqlalchemy.orm import Session
from sqlalchemy import text
from api.auth import router as auth_router
from api.generate import router as generate_router
import os
from database.db import engine
from fastapi.staticfiles import StaticFiles

# routers

dotenv_path = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(dotenv_path)

server_host = os.getenv("SERVER_HOST", "127.0.0.1")
server_port = int(os.getenv("SERVER_PORT", 9001))

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(generate_router)
app.mount(
    "/storage",
    StaticFiles(directory="storage"),
    name="storage"
)


@app.get("/")
def get_root():
    return {"message": "Hello, World!"}


@app.get("/health")
def health_db():
    return {"database": "ok"}


@app.get("/health/db")
def health_db():
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))
    return {"status": "db ok"}
