from sqlalchemy.orm import Session
from database.models import GeneratedImageRecord, ImageGenerationStatus


def create_generated_image_record(
    db: Session,
    generated_by: str,
    model_used: str,
    prompt: str,
    image_name: str | None = None,
    status: ImageGenerationStatus | str = ImageGenerationStatus.Success,
    error: str | None = None,
) -> GeneratedImageRecord:
    if isinstance(status, str):
        status = ImageGenerationStatus(status)
    record = GeneratedImageRecord(
        generated_by=generated_by,
        model_used=model_used,
        prompt=prompt,
        image_name=image_name,
        status=status,
        error=error,
    )

    # Optional: provide image_name yourself. If None, DB default generates it.
    if image_name is not None:
        record.image_name = image_name

    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def get_generated_images(db: Session, ffrom: int = 0, to: int = 10) -> list[GeneratedImageRecord]:
    return (
        db.query(GeneratedImageRecord)
        .where(GeneratedImageRecord.status != ImageGenerationStatus.Failed)
        .order_by(GeneratedImageRecord.created_at.desc())
        .slice(ffrom, to)
        .all()
    )
